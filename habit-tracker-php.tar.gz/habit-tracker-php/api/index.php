<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$dbPath = __DIR__ . '/../data/habits.db';
$db = new SQLite3($dbPath);
$db->busyTimeout(5000);
$db->exec('PRAGMA journal_mode=WAL');
$db->exec('PRAGMA foreign_keys=ON');

$db->exec('CREATE TABLE IF NOT EXISTS habits (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    icon TEXT DEFAULT "",
    color TEXT DEFAULT "#6366f1",
    category TEXT DEFAULT "other",
    priority TEXT DEFAULT "medium",
    frequency TEXT DEFAULT "daily",
    rest_days TEXT DEFAULT "[]",
    goal INTEGER DEFAULT 7,
    description TEXT DEFAULT "",
    tags TEXT DEFAULT "[]",
    "group" TEXT DEFAULT "",
    reminder TEXT DEFAULT "",
    created_at TEXT DEFAULT (datetime("now"))
)');

$db->exec('CREATE TABLE IF NOT EXISTS completions (
    habit_id TEXT NOT NULL,
    date TEXT NOT NULL,
    time_of_day TEXT DEFAULT "",
    note TEXT DEFAULT "",
    PRIMARY KEY (habit_id, date),
    FOREIGN KEY (habit_id) REFERENCES habits(id) ON DELETE CASCADE
)');

$db->exec('CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
)');

$db->exec('CREATE TABLE IF NOT EXISTS tags (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    color TEXT DEFAULT "#6366f1"
)');

$db->exec('CREATE TABLE IF NOT EXISTS profiles (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    icon TEXT DEFAULT "👤",
    is_active INTEGER DEFAULT 0
)');

$db->exec('CREATE TABLE IF NOT EXISTS mood (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    mood INTEGER DEFAULT 3,
    energy INTEGER DEFAULT 3,
    notes TEXT DEFAULT "",
    created_at TEXT DEFAULT (datetime("now"))
)');

$db->exec('CREATE TABLE IF NOT EXISTS sleep (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    hours REAL DEFAULT 7,
    quality INTEGER DEFAULT 3,
    notes TEXT DEFAULT "",
    created_at TEXT DEFAULT (datetime("now"))
)');

$db->exec('CREATE TABLE IF NOT EXISTS water (
    date TEXT PRIMARY KEY,
    glasses INTEGER DEFAULT 0
)');

$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path = preg_replace('#^.*api/?#', '', $path);
$path = trim($path, '/');

function jsonInput() {
    return json_decode(file_get_contents('php://input'), true);
}

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

try {
    $parts = explode('/', $path);
    $resource = $parts[0] ?? '';

    switch ($resource) {
        case 'habits':
            if ($method === 'GET') {
                $rows = $db->query('SELECT * FROM habits ORDER BY created_at DESC');
                $habits = [];
                while ($row = $rows->fetchArray(SQLITE3_ASSOC)) {
                    $row['rest_days'] = json_decode($row['rest_days'], true);
                    $row['tags'] = json_decode($row['tags'], true);
                    $comps = $db->query("SELECT date, time_of_day, note FROM completions WHERE habit_id='" . SQLite3::escapeString($row['id']) . "'");
                    $row['completions'] = [];
                    while ($c = $comps->fetchArray(SQLITE3_ASSOC)) {
                        $row['completions'][$c['date']] = ['timeOfDay' => $c['time_of_day'], 'note' => $c['note']];
                    }
                    $habits[] = $row;
                }
                jsonResponse(['habits' => $habits]);
            }
            if ($method === 'POST') {
                $data = jsonInput();
                $id = $data['id'] ?? ('h_' . uniqid());
                $stmt = $db->prepare('INSERT OR REPLACE INTO habits (id, name, icon, color, category, priority, frequency, rest_days, goal, description, tags, "group", reminder) VALUES (:id, :name, :icon, :color, :category, :priority, :frequency, :rest_days, :goal, :description, :tags, :group, :reminder)');
                $stmt->bindValue(':id', $id);
                $stmt->bindValue(':name', $data['name'] ?? '');
                $stmt->bindValue(':icon', $data['icon'] ?? '');
                $stmt->bindValue(':color', $data['color'] ?? '#6366f1');
                $stmt->bindValue(':category', $data['category'] ?? 'other');
                $stmt->bindValue(':priority', $data['priority'] ?? 'medium');
                $stmt->bindValue(':frequency', $data['frequency'] ?? 'daily');
                $stmt->bindValue(':rest_days', json_encode($data['rest_days'] ?? []));
                $stmt->bindValue(':goal', $data['goal'] ?? 7);
                $stmt->bindValue(':description', $data['description'] ?? '');
                $stmt->bindValue(':tags', json_encode($data['tags'] ?? []));
                $stmt->bindValue(':group', $data['group'] ?? '');
                $stmt->bindValue(':reminder', $data['reminder'] ?? '');
                $stmt->execute();
                jsonResponse(['id' => $id, 'ok' => true], 201);
            }
            if ($method === 'DELETE') {
                $id = $parts[1] ?? '';
                if ($id) {
                    $db->exec("DELETE FROM habits WHERE id='" . SQLite3::escapeString($id) . "'");
                    $db->exec("DELETE FROM completions WHERE habit_id='" . SQLite3::escapeString($id) . "'");
                }
                jsonResponse(['ok' => true]);
            }
            break;

        case 'completions':
            if ($method === 'POST') {
                $data = jsonInput();
                $hid = $data['habit_id'] ?? '';
                $date = $data['date'] ?? '';
                if ($data['completed']) {
                    $stmt = $db->prepare('INSERT OR REPLACE INTO completions (habit_id, date, time_of_day, note) VALUES (:hid, :date, :tod, :note)');
                    $stmt->bindValue(':hid', $hid);
                    $stmt->bindValue(':date', $date);
                    $stmt->bindValue(':tod', $data['time_of_day'] ?? '');
                    $stmt->bindValue(':note', $data['note'] ?? '');
                    $stmt->execute();
                } else {
                    $db->exec("DELETE FROM completions WHERE habit_id='" . SQLite3::escapeString($hid) . "' AND date='" . SQLite3::escapeString($date) . "'");
                }
                jsonResponse(['ok' => true]);
            }
            break;

        case 'settings':
            if ($method === 'GET') {
                $rows = $db->query('SELECT * FROM settings');
                $settings = [];
                while ($row = $rows->fetchArray(SQLITE3_ASSOC)) {
                    $settings[$row['key']] = json_decode($row['value'], true);
                }
                jsonResponse(['settings' => $settings]);
            }
            if ($method === 'POST') {
                $data = jsonInput();
                foreach ($data as $key => $value) {
                    $stmt = $db->prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (:key, :value)');
                    $stmt->bindValue(':key', $key);
                    $stmt->bindValue(':value', json_encode($value));
                    $stmt->execute();
                }
                jsonResponse(['ok' => true]);
            }
            break;

        case 'tags':
            if ($method === 'GET') {
                $rows = $db->query('SELECT * FROM tags');
                $tags = [];
                while ($row = $rows->fetchArray(SQLITE3_ASSOC)) {
                    $tags[] = $row;
                }
                jsonResponse(['tags' => $tags]);
            }
            if ($method === 'POST') {
                $data = jsonInput();
                $id = $data['id'] ?? ('t_' . uniqid());
                $stmt = $db->prepare('INSERT OR REPLACE INTO tags (id, name, color) VALUES (:id, :name, :color)');
                $stmt->bindValue(':id', $id);
                $stmt->bindValue(':name', $data['name'] ?? '');
                $stmt->bindValue(':color', $data['color'] ?? '#6366f1');
                $stmt->execute();
                jsonResponse(['id' => $id, 'ok' => true], 201);
            }
            if ($method === 'DELETE') {
                $id = $parts[1] ?? '';
                $db->exec("DELETE FROM tags WHERE id='" . SQLite3::escapeString($id) . "'");
                jsonResponse(['ok' => true]);
            }
            break;

        case 'mood':
            if ($method === 'GET') {
                $rows = $db->query('SELECT * FROM mood ORDER BY date DESC LIMIT 365');
                $moods = [];
                while ($row = $rows->fetchArray(SQLITE3_ASSOC)) {
                    $moods[] = $row;
                }
                jsonResponse(['mood' => $moods]);
            }
            if ($method === 'POST') {
                $data = jsonInput();
                $stmt = $db->prepare('INSERT INTO mood (date, mood, energy, notes) VALUES (:date, :mood, :energy, :notes)');
                $stmt->bindValue(':date', $data['date'] ?? date('Y-m-d'));
                $stmt->bindValue(':mood', $data['mood'] ?? 3);
                $stmt->bindValue(':energy', $data['energy'] ?? 3);
                $stmt->bindValue(':notes', $data['notes'] ?? '');
                $stmt->execute();
                jsonResponse(['id' => $db->lastInsertRowID(), 'ok' => true], 201);
            }
            break;

        case 'sleep':
            if ($method === 'GET') {
                $rows = $db->query('SELECT * FROM sleep ORDER BY date DESC LIMIT 365');
                $sleeps = [];
                while ($row = $rows->fetchArray(SQLITE3_ASSOC)) {
                    $sleeps[] = $row;
                }
                jsonResponse(['sleep' => $sleeps]);
            }
            if ($method === 'POST') {
                $data = jsonInput();
                $stmt = $db->prepare('INSERT INTO sleep (date, hours, quality, notes) VALUES (:date, :hours, :quality, :notes)');
                $stmt->bindValue(':date', $data['date'] ?? date('Y-m-d'));
                $stmt->bindValue(':hours', $data['hours'] ?? 7);
                $stmt->bindValue(':quality', $data['quality'] ?? 3);
                $stmt->bindValue(':notes', $data['notes'] ?? '');
                $stmt->execute();
                jsonResponse(['id' => $db->lastInsertRowID(), 'ok' => true], 201);
            }
            break;

        case 'water':
            if ($method === 'GET') {
                $rows = $db->query('SELECT * FROM water ORDER BY date DESC LIMIT 365');
                $waters = [];
                while ($row = $rows->fetchArray(SQLITE3_ASSOC)) {
                    $waters[] = $row;
                }
                jsonResponse(['water' => $waters]);
            }
            if ($method === 'POST') {
                $data = jsonInput();
                $date = $data['date'] ?? date('Y-m-d');
                $glasses = $data['glasses'] ?? 0;
                $stmt = $db->prepare('INSERT OR REPLACE INTO water (date, glasses) VALUES (:date, :glasses)');
                $stmt->bindValue(':date', $date);
                $stmt->bindValue(':glasses', $glasses);
                $stmt->execute();
                jsonResponse(['ok' => true]);
            }
            break;

        case 'export':
            $all = [];
            $rows = $db->query('SELECT * FROM habits');
            $all['habits'] = [];
            while ($row = $rows->fetchArray(SQLITE3_ASSOC)) {
                $row['rest_days'] = json_decode($row['rest_days'], true);
                $row['tags'] = json_decode($row['tags'], true);
                $comps = $db->query("SELECT date, time_of_day, note FROM completions WHERE habit_id='" . SQLite3::escapeString($row['id']) . "'");
                $row['completions'] = [];
                while ($c = $comps->fetchArray(SQLITE3_ASSOC)) {
                    $row['completions'][$c['date']] = ['timeOfDay' => $c['time_of_day'], 'note' => $c['note']];
                }
                $all['habits'][] = $row;
            }
            $rows = $db->query('SELECT * FROM tags');
            $all['tags'] = [];
            while ($row = $rows->fetchArray(SQLITE3_ASSOC)) {
                $all['tags'][] = $row;
            }
            jsonResponse($all);
            break;

        default:
            jsonResponse(['error' => 'Not found', 'path' => $path], 404);
    }
} catch (Exception $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
}

$db->close();
?>
